import React from "react";

const Compliance = () => {
  return <>Compliance</>;
};

export default Compliance;
